package com.schenker.api2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Api2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
